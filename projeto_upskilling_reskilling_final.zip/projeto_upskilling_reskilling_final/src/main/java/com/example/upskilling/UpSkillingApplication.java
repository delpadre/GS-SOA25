package com.example.upskilling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UpSkillingApplication {
    public static void main(String[] args) {
        SpringApplication.run(UpSkillingApplication.class, args);
    }
}
