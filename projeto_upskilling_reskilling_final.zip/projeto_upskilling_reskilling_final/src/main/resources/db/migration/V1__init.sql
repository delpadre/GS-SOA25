-- Tabelas
CREATE TABLE usuarios (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  nome VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  area_atuacao VARCHAR(100),
  nivel_carreira VARCHAR(50),
  data_cadastro DATE NOT NULL
);

CREATE TABLE trilhas (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  nome VARCHAR(150) NOT NULL,
  descricao TEXT,
  nivel VARCHAR(50) NOT NULL,
  carga_horaria INT NOT NULL,
  foco_principal VARCHAR(100)
);

CREATE TABLE competencias (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  nome VARCHAR(100) NOT NULL,
  categoria VARCHAR(100),
  descricao TEXT
);

CREATE TABLE trilha_competencia (
  trilha_id BIGINT NOT NULL,
  competencia_id BIGINT NOT NULL,
  PRIMARY KEY (trilha_id, competencia_id)
);

CREATE TABLE matriculas (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  usuario_id BIGINT NOT NULL,
  trilha_id BIGINT NOT NULL,
  data_inscricao DATE NOT NULL,
  status VARCHAR(50) NOT NULL
);

-- Seeds: competencias
INSERT INTO competencias (nome, categoria, descricao) VALUES
('Inteligência Artificial','Tecnologia','Conhecimentos básicos em IA'),
('Análise de Dados','Tecnologia','Processamento e interpretação de dados'),
('Empatia e Comunicação','Humana','Habilidades interpessoais para ambientes de trabalho');

-- Seeds: trilhas
INSERT INTO trilhas (nome, descricao, nivel, carga_horaria, foco_principal) VALUES
('Fundamentos de IA','Introdução a conceitos de IA','INICIANTE',40,'IA'),
('Data Analytics para Negócios','Análise de dados aplicada a decisão','INTERMEDIARIO',60,'Dados');

-- Relacionamentos trilha_competencia (exemplo simples)
INSERT INTO trilha_competencia (trilha_id, competencia_id) VALUES (1,1),(2,2);

-- Seeds: usuario exemplo
INSERT INTO usuarios (nome,email,area_atuacao,nivel_carreira,data_cadastro) VALUES
('Aluno Exemplo','aluno@example.com','TI','Em transição', CURRENT_DATE());

-- Matricula exemplo
INSERT INTO matriculas (usuario_id,trilha_id,data_inscricao,status) VALUES (1,1,CURRENT_DATE(),'ATIVA');
