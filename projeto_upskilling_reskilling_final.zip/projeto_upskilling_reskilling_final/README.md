# Plataforma Upskilling/Reskilling - Projeto (ENTREGA FINAL)

## Resumo
API RESTful em **Java 21 + Spring Boot 3.x** com:
- CRUD Usuário, Trilha, Competência, Matrícula
- Persistência H2 + Flyway (migrations + seeds)
- Validações (Jakarta Validation)
- Documentação Swagger/OpenAPI
- Tratamento centralizado de exceções
- Testes unitários básicos (JUnit)
- Diagrama UML (arquivo `diagrama_classes.puml`)

## PDF com enunciado (arquivo que você carregou)
O enunciado original que orientou este projeto está incluído neste repositório: /mnt/data/futuro_do_trabalho_Upskilling_Reskilling-3ESPR.pdf

## Como rodar (local)
1. `mvn clean package`
2. `mvn spring-boot:run`
3. A aplicação roda em `http://localhost:8080`
4. H2 Console: `http://localhost:8080/h2-console` (jdbc:h2:mem:upskillingdb)
5. Swagger UI: `http://localhost:8080/swagger-ui.html`

## Exemplos de payloads (curl)
Criar usuário:
```
curl -X POST http://localhost:8080/api/usuarios -H 'Content-Type: application/json' -d '{"nome":"Aluno","email":"aluno@example.com","areaAtuacao":"TI","nivelCarreira":"Em transição"}'
```

Criar trilha (associando competências existentes):
```
curl -X POST http://localhost:8080/api/trilhas -H 'Content-Type: application/json' -d '{"nome":"Fundamentos de IA","descricao":"...","nivel":"INICIANTE","cargaHoraria":40,"competenciaIds":[1]}'
```

Inscrever usuário em trilha:
```
curl -X POST http://localhost:8080/api/matriculas -H 'Content-Type: application/json' -d '{"usuarioId":1,"trilhaId":1}'
```

## Justificativa teórica (resumo que a professora costuma pedir)
**Upskilling** = aperfeiçoamento das habilidades atuais de um trabalhador para manter a relevância diante de novas tecnologias.
**Reskilling** = requalificação para uma nova função ou área quando a função atual é impactada por automação/IA.

## Diagrama de classes (PlantUML)
Arquivo: `diagrama_classes.puml` (aberto com qualquer visualizador PlantUML)
